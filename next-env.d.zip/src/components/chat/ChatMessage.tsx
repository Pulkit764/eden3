import { motion } from 'framer-motion';
import { FaRobot, FaUser, FaExclamationTriangle } from 'react-icons/fa';
import { marked } from 'marked';

interface ChatMessageProps {
  message: {
    role: string;
    content: string;
    timestamp: string;
    isError?: boolean;
  };
}

const ChatMessage = ({ message }: ChatMessageProps) => {
  const isUser = message.role === 'user';
  const formattedTime = new Date(message.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  
  // Use marked to render markdown in assistant responses
  const renderedContent = !isUser ? marked.parse(message.content) : message.content;
  
  return (
    <div className={`flex ${isUser ? 'justify-end' : 'justify-start'}`}>
      <div className={`flex max-w-[80%] ${isUser ? 'flex-row-reverse' : ''}`}>
        {/* Avatar */}
        <div className={`flex-shrink-0 h-8 w-8 rounded-full flex items-center justify-center ${
          isUser ? 'bg-primary-600 ml-2' : message.isError ? 'bg-red-600 mr-2' : 'bg-primary-100 text-primary-600 mr-2'
        }`}>
          {isUser ? (
            <FaUser className="h-4 w-4 text-white" />
          ) : message.isError ? (
            <FaExclamationTriangle className="h-4 w-4 text-white" />
          ) : (
            <FaRobot className="h-4 w-4" />
          )}
        </div>
        
        {/* Message content */}
        <div className={`px-4 py-3 rounded-lg ${
          isUser 
            ? 'bg-primary-600 text-white rounded-tr-none' 
            : message.isError 
              ? 'bg-red-100 text-red-700 rounded-tl-none' 
              : 'bg-primary-100 text-gray-800 rounded-tl-none'
        }`}>
          {isUser ? (
            <p>{message.content}</p>
          ) : (
            <div className="prose prose-sm max-w-none" dangerouslySetInnerHTML={{ __html: renderedContent }} />
          )}
          <div className={`text-xs mt-1 text-right ${isUser ? 'text-primary-200' : 'text-gray-500'}`}>
            {formattedTime}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChatMessage;