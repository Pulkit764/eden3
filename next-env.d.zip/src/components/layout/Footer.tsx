import Link from 'next/link';
import { useTranslation } from 'react-i18next';
import { FaHeart, FaTwitter, FaFacebook, FaInstagram, FaGithub } from 'react-icons/fa';

const Footer = () => {
  const { t } = useTranslation();
  
  return (
    <footer className="bg-gray-800 text-gray-300">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* About section */}
          <div>
            <h3 className="text-white text-lg font-bold mb-4">{t('footer.about.title', 'About EDEN')}</h3>
            <p className="mb-4 text-sm leading-relaxed">
              {t('footer.about.description', 'EDEN is an AI-powered food system navigator helping people make informed, sustainable, and healthy food choices anywhere in the world.')}
            </p>
            <p className="text-sm flex items-center">
              {t('footer.about.madeWith', 'Made with')} <FaHeart className="mx-1 text-red-500" /> {t('footer.about.forEveryone', 'for everyone')}
            </p>
          </div>
          
          {/* Features */}
          <div>
            <h3 className="text-white text-lg font-bold mb-4">{t('footer.features.title', 'Features')}</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/chat" className="hover:text-white transition">
                  {t('footer.features.aiCoach', 'AI Nutrition Coach')}
                </Link>
              </li>
              <li>
                <Link href="/meals" className="hover:text-white transition">
                  {t('footer.features.meals', 'Personalized Meals')}
                </Link>
              </li>
              <li>
                <Link href="/fact-check" className="hover:text-white transition">
                  {t('footer.features.factCheck', 'Food Misinformation Scanner')}
                </Link>
              </li>
              <li>
                <Link href="/map" className="hover:text-white transition">
                  {t('footer.features.map', 'Local Food Map')}
                </Link>
              </li>
            </ul>
          </div>
          
          {/* Resources */}
          <div>
            <h3 className="text-white text-lg font-bold mb-4">{t('footer.resources.title', 'Resources')}</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/blog" className="hover:text-white transition">
                  {t('footer.resources.blog', 'Blog')}
                </Link>
              </li>
              <li>
                <Link href="/research" className="hover:text-white transition">
                  {t('footer.resources.research', 'Research')}
                </Link>
              </li>
              <li>
                <Link href="/community" className="hover:text-white transition">
                  {t('footer.resources.community', 'Community')}
                </Link>
              </li>
              <li>
                <Link href="/help" className="hover:text-white transition">
                  {t('footer.resources.help', 'Help Center')}
                </Link>
              </li>
            </ul>
          </div>
          
          {/* Contact & Legal */}
          <div>
            <h3 className="text-white text-lg font-bold mb-4">{t('footer.legal.title', 'Legal')}</h3>
            <ul className="space-y-2 text-sm mb-6">
              <li>
                <Link href="/terms" className="hover:text-white transition">
                  {t('footer.legal.terms', 'Terms of Service')}
                </Link>
              </li>
              <li>
                <Link href="/privacy" className="hover:text-white transition">
                  {t('footer.legal.privacy', 'Privacy Policy')}
                </Link>
              </li>
              <li>
                <Link href="/accessibility" className="hover:text-white transition">
                  {t('footer.legal.accessibility', 'Accessibility')}
                </Link>
              </li>
            </ul>
            
            <h3 className="text-white text-lg font-bold mb-2">{t('footer.contact.title', 'Connect')}</h3>
            <div className="flex space-x-4">
              <a href="#" aria-label="Twitter" className="text-gray-400 hover:text-white transition">
                <FaTwitter className="h-5 w-5" />
              </a>
              <a href="#" aria-label="Facebook" className="text-gray-400 hover:text-white transition">
                <FaFacebook className="h-5 w-5" />
              </a>
              <a href="#" aria-label="Instagram" className="text-gray-400 hover:text-white transition">
                <FaInstagram className="h-5 w-5" />
              </a>
              <a href="#" aria-label="GitHub" className="text-gray-400 hover:text-white transition">
                <FaGithub className="h-5 w-5" />
              </a>
            </div>
          </div>
        </div>
        
        <div className="border-t border-gray-700 mt-8 pt-8 text-sm text-center">
          <p>
            &copy; {new Date().getFullYear()} EDEN. {t('footer.copyright', 'All rights reserved.')}
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;