import { useState, useEffect } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/router';
import { useTranslation } from 'react-i18next';
import { motion } from 'framer-motion';
import { FaBars, FaUser, FaGlobe, FaSearch, FaSignOutAlt } from 'react-icons/fa';
import useUserStore from '../../store/userStore';
import { logout } from '../../services/authService';

interface HeaderProps {
  toggleSidebar: () => void;
}

const Header = ({ toggleSidebar }: HeaderProps) => {
  const { t, i18n } = useTranslation();
  const [isScrolled, setIsScrolled] = useState(false);
  const [isLanguageDropdownOpen, setIsLanguageDropdownOpen] = useState(false);
  const [isUserDropdownOpen, setIsUserDropdownOpen] = useState(false);
  const router = useRouter();
  
  const { userProfile } = useUserStore();
  
  // Add scroll event listener to change header style on scroll
  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 10) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };
    
    window.addEventListener('scroll', handleScroll);
    
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);
  
  const changeLanguage = (lng: string) => {
    i18n.changeLanguage(lng);
    setIsLanguageDropdownOpen(false);
  };
  
  const handleLogout = async () => {
    try {
      await logout();
      router.push('/login');
    } catch (error) {
      console.error('Logout error:', error);
    }
  };

  return (
    <header className={`fixed top-0 left-0 right-0 z-20 transition-all duration-300 ${
      isScrolled ? 'bg-white shadow-md py-2' : 'bg-transparent py-4'
    }`}>
      <div className="container mx-auto px-4 flex items-center justify-between">
        {/* Left section - Logo and mobile menu */}
        <div className="flex items-center">
          <button 
            onClick={toggleSidebar}
            className="mr-4 p-2 rounded-full hover:bg-gray-100 lg:hidden"
            aria-label="Toggle menu"
          >
            <FaBars className="h-5 w-5 text-gray-700" />
          </button>
          
          <Link href="/" passHref className="flex items-center">
            <div className="h-10 w-10 rounded-full bg-primary-600 flex items-center justify-center text-white font-bold text-xl">E</div>
            <span className={`ml-2 font-display font-bold text-xl ${isScrolled ? 'text-primary-600' : 'text-white lg:text-primary-600'}`}>
              EDEN
            </span>
          </Link>
        </div>
        
        {/* Center section - Navigation (desktop only) */}
        <nav className="hidden lg:flex space-x-6">
          {[
            { name: t('nav.home'), href: '/' },
            { name: t('nav.chat'), href: '/chat' },
            { name: t('nav.meals'), href: '/meals' },
            { name: t('nav.factCheck'), href: '/fact-check' },
          ].map(item => (
            <Link 
              key={item.href} 
              href={item.href}
              className={`font-medium hover:text-primary-600 transition ${
                router.pathname === item.href ? 'text-primary-600' : isScrolled ? 'text-gray-800' : 'text-white'
              }`}
            >
              {item.name}
            </Link>
          ))}
        </nav>
        
        {/* Right section - Search, Language, User */}
        <div className="flex items-center space-x-4">
          {/* Search button */}
          <button 
            className={`p-2 rounded-full hover:bg-gray-100 ${isScrolled ? 'text-gray-700' : 'text-white lg:text-gray-700'}`}
            aria-label="Search"
          >
            <FaSearch className="h-5 w-5" />
          </button>
          
          {/* Language selector */}
          <div className="relative">
            <button 
              onClick={() => setIsLanguageDropdownOpen(!isLanguageDropdownOpen)}
              className={`p-2 rounded-full hover:bg-gray-100 flex items-center ${isScrolled ? 'text-gray-700' : 'text-white lg:text-gray-700'}`}
              aria-label="Select language"
            >
              <FaGlobe className="h-5 w-5" />
            </button>
            
            {isLanguageDropdownOpen && (
              <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 10 }}
                className="absolute right-0 mt-2 w-40 bg-white rounded-md shadow-lg py-1 z-50"
              >
                {[
                  { code: 'en', name: 'English' },
                  { code: 'es', name: 'Español' },
                  { code: 'fr', name: 'Français' },
                  { code: 'zh', name: '中文' },
                  { code: 'hi', name: 'हिन्दी' },
                  { code: 'ar', name: 'العربية' },
                  { code: 'sw', name: 'Kiswahili' }
                ].map(lang => (
                  <button
                    key={lang.code}
                    onClick={() => changeLanguage(lang.code)}
                    className={`block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 w-full text-left ${
                      i18n.language === lang.code ? 'font-bold bg-gray-50' : ''
                    }`}
                  >
                    {lang.name}
                  </button>
                ))}
              </motion.div>
            )}
          </div>
          
          {/* User menu */}
          <div className="relative">
            <button 
              onClick={() => setIsUserDropdownOpen(!isUserDropdownOpen)}
              className={`p-2 rounded-full hover:bg-gray-100 ${isScrolled ? 'text-gray-700' : 'text-white lg:text-gray-700'}`}
              aria-label="User menu"
            >
              <FaUser className="h-5 w-5" />
            </button>
            
            {isUserDropdownOpen && (
              <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 10 }}
                className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-50"
              >
                {userProfile ? (
                  <>
                    <div className="px-4 py-2 border-b border-gray-100">
                      <p className="text-sm font-medium text-gray-900">{userProfile.name}</p>
                      <p className="text-xs text-gray-500 truncate">{userProfile.email}</p>
                    </div>
                    <Link href="/profile" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                      {t('nav.profile')}
                    </Link>
                    <button 
                      onClick={handleLogout}
                      className="flex items-center w-full px-4 py-2 text-sm text-red-600 hover:bg-gray-100"
                    >
                      <FaSignOutAlt className="mr-2 h-4 w-4" />
                      {t('nav.logout')}
                    </button>
                  </>
                ) : (
                  <>
                    <Link href="/login" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                      {t('nav.login')}
                    </Link>
                    <Link href="/signup" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                      {t('nav.signup')}
                    </Link>
                  </>
                )}
              </motion.div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;