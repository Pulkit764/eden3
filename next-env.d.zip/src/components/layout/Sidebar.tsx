import { useTranslation } from 'react-i18next';
import { motion, AnimatePresence } from 'framer-motion';
import Link from 'next/link';
import { useRouter } from 'next/router';
import { FaTimes, FaHome, FaComments, FaUtensils, FaShieldAlt, FaMapMarkerAlt, FaLeaf, FaUsers, FaUserCircle } from 'react-icons/fa';

interface SidebarProps {
  isOpen: boolean;
  closeSidebar: () => void;
}

const Sidebar = ({ isOpen, closeSidebar }: SidebarProps) => {
  const { t } = useTranslation();
  const router = useRouter();
  
  // Define navigation items
  const navItems = [
    { icon: <FaHome />, name: t('nav.home'), href: '/' },
    { icon: <FaComments />, name: t('nav.chat'), href: '/chat' },
    { icon: <FaUtensils />, name: t('nav.meals'), href: '/meals' },
    { icon: <FaShieldAlt />, name: t('nav.factCheck'), href: '/fact-check' },
    { icon: <FaMapMarkerAlt />, name: t('nav.foodMap'), href: '/map', comingSoon: true },
    { icon: <FaLeaf />, name: t('nav.impact'), href: '/impact', comingSoon: true },
    { icon: <FaUsers />, name: t('nav.community'), href: '/community', comingSoon: true },
  ];

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Overlay */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.5 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black z-30 lg:hidden"
            onClick={closeSidebar}
          />
          
          {/* Sidebar */}
          <motion.div
            initial={{ x: '-100%' }}
            animate={{ x: 0 }}
            exit={{ x: '-100%' }}
            transition={{ type: 'tween' }}
            className="fixed top-0 left-0 h-screen w-64 bg-white shadow-xl z-40 flex flex-col"
          >
            {/* Sidebar header */}
            <div className="px-4 py-5 flex items-center justify-between border-b border-gray-200">
              <Link href="/" className="flex items-center" onClick={closeSidebar}>
                <div className="h-8 w-8 bg-primary-600 rounded-full flex items-center justify-center text-white font-bold">
                  E
                </div>
                <span className="ml-2 font-display font-bold text-lg text-gray-900">EDEN</span>
              </Link>
              
              <button 
                onClick={closeSidebar}
                className="p-2 rounded-full hover:bg-gray-100 text-gray-500"
                aria-label="Close sidebar"
              >
                <FaTimes />
              </button>
            </div>
            
            {/* Navigation links */}
            <nav className="flex-1 px-2 py-4 overflow-y-auto">
              <ul className="space-y-1">
                {navItems.map((item) => (
                  <li key={item.href}>
                    <Link
                      href={item.comingSoon ? '#' : item.href}
                      className={`flex items-center px-4 py-3 rounded-lg text-gray-700 hover:bg-primary-50 hover:text-primary-600 ${
                        router.pathname === item.href ? 'bg-primary-50 text-primary-600 font-medium' : ''
                      }`}
                      onClick={item.comingSoon ? (e) => e.preventDefault() : closeSidebar}
                    >
                      <span className="mr-3 text-lg">{item.icon}</span>
                      <span>{item.name}</span>
                      {item.comingSoon && (
                        <span className="ml-auto text-xs px-2 py-1 bg-gray-200 text-gray-600 rounded-full">
                          {t('nav.comingSoon', 'Soon')}
                        </span>
                      )}
                    </Link>
                  </li>
                ))}
              </ul>
            </nav>
            
            {/* Profile section */}
            <div className="p-4 border-t border-gray-200">
              <Link
                href="/profile"
                className="flex items-center px-4 py-3 rounded-lg text-gray-700 hover:bg-primary-50 hover:text-primary-600"
                onClick={closeSidebar}
              >
                <FaUserCircle className="mr-3 text-lg" />
                <span>{t('nav.profile', 'Your Profile')}</span>
              </Link>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};

export default Sidebar;