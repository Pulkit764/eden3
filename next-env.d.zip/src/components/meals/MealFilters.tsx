import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { FaFilter, FaClock, FaDollarSign } from 'react-icons/fa';
import { motion } from 'framer-motion';

interface MealFiltersProps {
  filters: {
    mealType: string;
    diet: string;
    maxTime: number;
    maxCost: number;
    includeIngredients: string[];
    excludeIngredients: string[];
  };
  onChange: (filters: any) => void;
  userProfile: any;
}

const MealFilters = ({ filters, onChange, userProfile }: MealFiltersProps) => {
  const { t } = useTranslation();
  const [isAdvancedOpen, setIsAdvancedOpen] = useState(false);
  const [includeIngredient, setIncludeIngredient] = useState('');
  const [excludeIngredient, setExcludeIngredient] = useState('');

  const handleMealTypeChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    onChange({ mealType: e.target.value });
  };

  const handleDietChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    onChange({ diet: e.target.value });
  };

  const handleTimeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    onChange({ maxTime: parseInt(e.target.value) });
  };

  const handleCostChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    onChange({ maxCost: parseInt(e.target.value) });
  };

  const addIncludeIngredient = () => {
    if (includeIngredient.trim()) {
      onChange({ 
        includeIngredients: [...filters.includeIngredients, includeIngredient.trim()] 
      });
      setIncludeIngredient('');
    }
  };

  const removeIncludeIngredient = (ingredient: string) => {
    onChange({
      includeIngredients: filters.includeIngredients.filter(item => item !== ingredient)
    });
  };

  const addExcludeIngredient = () => {
    if (excludeIngredient.trim()) {
      onChange({ 
        excludeIngredients: [...filters.excludeIngredients, excludeIngredient.trim()] 
      });
      setExcludeIngredient('');
    }
  };

  const removeExcludeIngredient = (ingredient: string) => {
    onChange({
      excludeIngredients: filters.excludeIngredients.filter(item => item !== ingredient)
    });
  };

  return (
    <div className="bg-white p-4 rounded-xl shadow-md mb-6">
      <div className="flex flex-col md:flex-row md:items-center mb-4">
        <div className="mb-4 md:mb-0 md:mr-4 md:w-1/4">
          <label className="block text-sm font-medium text-gray-700 mb-1">
            {t('meals.filters.mealType', 'Meal Type')}
          </label>
          <select
            value={filters.mealType}
            onChange={handleMealTypeChange}
            className="w-full p-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500"
          >
            <option value="all">{t('meals.filters.allMeals', 'All Meals')}</option>
            <option value="breakfast">{t('meals.filters.breakfast', 'Breakfast')}</option>
            <option value="lunch">{t('meals.filters.lunch', 'Lunch')}</option>
            <option value="dinner">{t('meals.filters.dinner', 'Dinner')}</option>
            <option value="snack">{t('meals.filters.snack', 'Snack')}</option>
          </select>
        </div>
        
        <div className="mb-4 md:mb-0 md:mr-4 md:w-1/4">
          <label className="block text-sm font-medium text-gray-700 mb-1">
            {t('meals.filters.diet', 'Diet')}
          </label>
          <select
            value={filters.diet}
            onChange={handleDietChange}
            className="w-full p-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500"
          >
            <option value="all">{t('meals.filters.allDiets', 'All Diets')}</option>
            <option value="vegetarian">{t('meals.filters.vegetarian', 'Vegetarian')}</option>
            <option value="vegan">{t('meals.filters.vegan', 'Vegan')}</option>
            <option value="gluten-free">{t('meals.filters.glutenFree', 'Gluten-Free')}</option>
            <option value="dairy-free">{t('meals.filters.dairyFree', 'Dairy-Free')}</option>
            <option value="keto">{t('meals.filters.keto', 'Keto')}</option>
            <option value="paleo">{t('meals.filters.paleo', 'Paleo')}</option>
          </select>
        </div>
        
        <div className="mb-4 md:mb-0 md:mr-4 md:w-1/4">
          <label className="flex items-center text-sm font-medium text-gray-700 mb-1">
            <FaClock className="mr-1" /> {t('meals.filters.maxTime', 'Max Time')}
          </label>
          <div className="flex items-center">
            <input
              type="range"
              min="5"
              max="120"
              step="5"
              value={filters.maxTime}
              onChange={handleTimeChange}
              className="w-full"
            />
            <span className="ml-2 text-sm font-medium text-gray-700 w-16">
              {filters.maxTime} min
            </span>
          </div>
        </div>
        
        <div className="md:w-1/4">
          <label className="flex items-center text-sm font-medium text-gray-700 mb-1">
            <FaDollarSign className="mr-1" /> {t('meals.filters.budget', 'Budget')}
          </label>
          <div className="flex items-center">
            <input
              type="range"
              min="1"
              max="3"
              step="1"
              value={filters.maxCost}
              onChange={handleCostChange}
              className="w-full"
            />
            <span className="ml-2 text-sm font-medium text-gray-700 w-16">
              {'$'.repeat(filters.maxCost)}
            </span>
          </div>
        </div>
      </div>
      
      <div className="border-t border-gray-200 pt-4">
        <button 
          onClick={() => setIsAdvancedOpen(!isAdvancedOpen)}
          className="flex items-center text-primary-600 hover:text-primary-700 font-medium text-sm"
        >
          <FaFilter className="mr-1" />
          {isAdvancedOpen ? 
            t('meals.filters.hideAdvanced', 'Hide Advanced Filters') : 
            t('meals.filters.showAdvanced', 'Show Advanced Filters')
          }
        </button>
        
        {isAdvancedOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4"
          >
            {/* Include ingredients */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {t('meals.filters.includeIngredients', 'Include Ingredients')}
              </label>
              <div className="flex">
                <input
                  type="text"
                  value={includeIngredient}
                  onChange={(e) => setIncludeIngredient(e.target.value)}
                  className="flex-grow p-2 border border-gray-300 rounded-l-lg focus:ring-primary-500 focus:border-primary-500"
                  placeholder={t('meals.filters.ingredientPlaceholder', 'e.g., chicken')}
                />
                <button
                  onClick={addIncludeIngredient}
                  className="px-4 py-2 bg-primary-600 text-white rounded-r-lg hover:bg-primary-700 transition"
                  disabled={!includeIngredient.trim()}
                >
                  {t('meals.filters.add', 'Add')}
                </button>
              </div>
              {filters.includeIngredients.length > 0 && (
                <div className="mt-2 flex flex-wrap gap-2">
                  {filters.includeIngredients.map((ingredient, index) => (
                    <span 
                      key={index}
                      className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800"
                    >
                      {ingredient}
                      <button
                        onClick={() => removeIncludeIngredient(ingredient)}
                        className="ml-1 h-4 w-4 rounded-full flex items-center justify-center hover:bg-green-200"
                      >
                        ×
                      </button>
                    </span>
                  ))}
                </div>
              )}
            </div>
            
            {/* Exclude ingredients */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {t('meals.filters.excludeIngredients', 'Exclude Ingredients')}
              </label>
              <div className="flex">
                <input
                  type="text"
                  value={excludeIngredient}
                  onChange={(e) => setExcludeIngredient(e.target.value)}
                  className="flex-grow p-2 border border-gray-300 rounded-l-lg focus:ring-primary-500 focus:border-primary-500"
                  placeholder={t('meals.filters.ingredientPlaceholder', 'e.g., mushrooms')}
                />
                <button
                  onClick={addExcludeIngredient}
                  className="px-4 py-2 bg-red-600 text-white rounded-r-lg hover:bg-red-700 transition"
                  disabled={!excludeIngredient.trim()}
                >
                  {t('meals.filters.add', 'Add')}
                </button>
              </div>
              {filters.excludeIngredients.length > 0 && (
                <div className="mt-2 flex flex-wrap gap-2">
                  {filters.excludeIngredients.map((ingredient, index) => (
                    <span 
                      key={index}
                      className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-red-100 text-red-800"
                    >
                      {ingredient}
                      <button
                        onClick={() => removeExcludeIngredient(ingredient)}
                        className="ml-1 h-4 w-4 rounded-full flex items-center justify-center hover:bg-red-200"
                      >
                        ×
                      </button>
                    </span>
                  ))}
                </div>
              )}
            </div>
            
            {/* Add more advanced filters here as needed */}
          </motion.div>
        )}
      </div>
    </div>
  );
};

export default MealFilters;