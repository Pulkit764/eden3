import { motion } from 'framer-motion';

interface NutritionBadgeProps {
  label: string;
  value: number;
  unit: string;
}

const NutritionBadge = ({ label, value, unit }: NutritionBadgeProps) => {
  return (
    <motion.div 
      whileHover={{ y: -2 }}
      className="flex flex-col items-center"
    >
      <div className="text-xs font-medium text-gray-500">{label}</div>
      <div className="text-sm font-bold">
        {value}<span className="text-xs font-normal ml-0.5">{unit}</span>
      </div>
    </motion.div>
  );
};

export default NutritionBadge;