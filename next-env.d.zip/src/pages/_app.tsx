import '../styles/globals.css';
import type { AppProps } from 'next/app';
import { ErrorBoundary } from 'react-error-boundary';
import { useEffect } from 'react';
import { useRouter } from 'next/router';
import Layout from '../components/layout/Layout';
import ErrorFallback from '../components/common/ErrorFallback';
import { I18nextProvider } from 'react-i18next';
import i18n from '../utils/i18n';
import { initializeDB } from '../utils/db';

// Initialize indexedDB for offline support
if (typeof window !== 'undefined') {
  initializeDB();
}

function MyApp({ Component, pageProps }: AppProps) {
  const router = useRouter();

  // Check for offline status
  useEffect(() => {
    const handleOffline = () => {
      // Update app state to reflect offline mode
      console.log('App is offline');
    };

    const handleOnline = () => {
      // Update app state to reflect online mode
      console.log('App is online');
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  return (
    <I18nextProvider i18n={i18n}>
      <ErrorBoundary FallbackComponent={ErrorFallback}>
        <Layout>
          <Component {...pageProps} />
        </Layout>
      </ErrorBoundary>
    </I18nextProvider>
  );
}

export default MyApp;