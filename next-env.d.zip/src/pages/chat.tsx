import { NextPage } from 'next';
import { useState, useRef, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { motion, AnimatePresence } from 'framer-motion';
import { FaPaperPlane, FaMicrophone, FaSpinner } from 'react-icons/fa';
import useUserStore from '../store/userStore';
import useChatStore from '../store/chatStore';
import { sendMessage } from '../services/openaiService';
import ChatMessage from '../components/chat/ChatMessage';

const Chat: NextPage = () => {
  const { t } = useTranslation();
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  
  const { userProfile } = useUserStore();
  const { messages, addMessage } = useChatStore();

  // Speech recognition setup (for browsers that support it)
  let recognition: any = null;
  if (typeof window !== 'undefined' && 'webkitSpeechRecognition' in window) {
    // @ts-ignore
    recognition = new webkitSpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = true;
    
    recognition.onresult = (event: any) => {
      const transcript = Array.from(event.results)
        .map((result: any) => result[0])
        .map((result) => result.transcript)
        .join('');
      
      setInput(transcript);
      
      if (event.results[0].isFinal) {
        setIsListening(false);
      }
    };
    
    recognition.onend = () => {
      setIsListening(false);
    };
  }

  const handleSpeechInput = () => {
    if (!recognition) return;
    
    if (isListening) {
      recognition.stop();
      setIsListening(false);
    } else {
      recognition.start();
      setIsListening(true);
    }
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!input.trim()) return;
    
    const userMessage = {
      role: 'user',
      content: input,
      timestamp: new Date().toISOString(),
    };
    
    addMessage(userMessage);
    setInput('');
    setIsLoading(true);
    
    try {
      // Pass user profile for context
      const response = await sendMessage(input, userProfile, messages);
      
      const assistantMessage = {
        role: 'assistant',
        content: response.content,
        timestamp: new Date().toISOString(),
      };
      
      addMessage(assistantMessage);
    } catch (error) {
      console.error('Error sending message:', error);
      
      addMessage({
        role: 'assistant',
        content: t('chat.errorMessage', 'Sorry, I encountered an error. Please try again later.'),
        timestamp: new Date().toISOString(),
        isError: true,
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-3xl mx-auto bg-white rounded-xl shadow-md overflow-hidden">
          {/* Chat header */}
          <div className="bg-primary-600 px-6 py-4">
            <h1 className="text-xl font-bold text-white">
              {t('chat.title', 'EDEN AI Nutrition Coach')}
            </h1>
            <p className="text-primary-100 text-sm">
              {t('chat.subtitle', 'Ask me anything about nutrition, food, and healthy eating')}
            </p>
          </div>
          
          {/* Messages container */}
          <div className="px-6 py-4 h-[60vh] overflow-y-auto bg-gray-50">
            {messages.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full text-center">
                <div className="w-20 h-20 mb-4 text-primary-600">
                  <FaPaperPlane className="w-full h-full" />
                </div>
                <h2 className="text-xl font-bold text-gray-700 mb-2">
                  {t('chat.welcome.title', 'Welcome to EDEN')}
                </h2>
                <p className="text-gray-500 max-w-sm">
                  {t('chat.welcome.message', 'Ask me about meal ideas, nutrition advice, or dietary questions.')}
                </p>
                <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-4 w-full max-w-md">
                  {[
                    t('chat.suggestions.1', 'What should I eat for dinner?'),
                    t('chat.suggestions.2', 'Help me find high-protein vegetarian meals'),
                    t('chat.suggestions.3', 'Is oat milk healthy?'),
                    t('chat.suggestions.4', 'Give me budget-friendly meal ideas')
                  ].map((suggestion, index) => (
                    <button
                      key={index}
                      className="bg-white border border-primary-200 rounded-lg px-4 py-2 text-sm text-gray-700 hover:bg-primary-50 transition"
                      onClick={() => setInput(suggestion)}
                    >
                      {suggestion}
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                <AnimatePresence>
                  {messages.map((message, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.3 }}
                    >
                      <ChatMessage message={message} />
                    </motion.div>
                  ))}
                </AnimatePresence>
                {isLoading && (
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="p-4 rounded-lg rounded-tl-none bg-primary-100 max-w-[80%]"
                  >
                    <div className="flex items-center text-primary-600">
                      <FaSpinner className="animate-spin mr-2" />
                      <span>{t('chat.thinking', 'Thinking...')}</span>
                    </div>
                  </motion.div>
                )}
                <div ref={messagesEndRef} />
              </div>
            )}
          </div>
          
          {/* Input form */}
          <div className="px-6 py-4 bg-white border-t border-gray-200">
            <form onSubmit={handleSubmit} className="flex items-center">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder={t('chat.inputPlaceholder', 'Type your message...')}
                className="flex-grow p-3 rounded-l-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-primary-500"
                disabled={isLoading}
                ref={inputRef}
              />
              {recognition && (
                <button
                  type="button"
                  onClick={handleSpeechInput}
                  className={`p-3 text-white ${isListening ? 'bg-red-500' : 'bg-gray-500'}`}
                  disabled={isLoading}
                >
                  <FaMicrophone />
                </button>
              )}
              <button
                type="submit"
                className="p-3 bg-primary-600 text-white rounded-r-lg hover:bg-primary-700 transition disabled:bg-gray-400"
                disabled={isLoading || !input.trim()}
              >
                <FaPaperPlane />
              </button>
            </form>
            <div className="text-xs text-gray-500 mt-2">
              {t('chat.disclaimer', 'EDEN provides general nutrition information, not medical advice. Consult healthcare professionals for medical concerns.')}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Chat;