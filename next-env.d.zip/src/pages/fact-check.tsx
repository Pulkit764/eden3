import { NextPage } from 'next';
import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { motion } from 'framer-motion';
import { FaUpload, FaLink, FaCheckCircle, FaTimesCircle, FaInfoCircle } from 'react-icons/fa';
import { checkFoodInformation } from '../services/factCheckService';

const FactCheck: NextPage = () => {
  const { t } = useTranslation();
  const [mode, setMode] = useState<'url' | 'text'>('text');
  const [input, setInput] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!input.trim()) {
      setError(t('factCheck.emptyInput', 'Please enter some text or a URL to check'));
      return;
    }
    
    setIsAnalyzing(true);
    setError('');
    setResult(null);
    
    try {
      const checkResult = await checkFoodInformation(input, mode);
      setResult(checkResult);
    } catch (err) {
      console.error('Error checking information:', err);
      setError(t('factCheck.errorMessage', 'An error occurred while analyzing the information. Please try again.'));
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-3xl mx-auto">
          <h1 className="text-3xl font-bold text-gray-800 mb-2">
            {t('factCheck.title', 'Food Information Checker')}
          </h1>
          <p className="text-gray-600 mb-8">
            {t('factCheck.subtitle', 'Verify food and nutrition claims to separate fact from fiction')}
          </p>

          <div className="bg-white rounded-xl shadow-md overflow-hidden mb-8">
            <div className="p-6">
              {/* Input mode selection */}
              <div className="flex mb-6">
                <button
                  className={`flex-1 py-2 px-4 border-b-2 ${mode === 'text' ? 'border-primary-600 text-primary-600' : 'border-gray-200 text-gray-500'}`}
                  onClick={() => setMode('text')}
                >
                  {t('factCheck.textMode', 'Check Text')}
                </button>
                <button
                  className={`flex-1 py-2 px-4 border-b-2 ${mode === 'url' ? 'border-primary-600 text-primary-600' : 'border-gray-200 text-gray-500'}`}
                  onClick={() => setMode('url')}
                >
                  {t('factCheck.urlMode', 'Check URL')}
                </button>
              </div>
              
              <form onSubmit={handleSubmit}>
                {mode === 'text' ? (
                  <textarea
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    placeholder={t('factCheck.textPlaceholder', 'Paste or type the nutrition or food claim to verify...')}
                    className="w-full h-32 p-3 border border-gray-300 rounded-lg resize-none focus:outline-none focus:ring-2 focus:ring-primary-500"
                    disabled={isAnalyzing}
                  />
                ) : (
                  <div className="flex items-center">
                    <div className="flex-grow">
                      <input
                        type="url"
                        value={input}
                        onChange={(e) => setInput(e.target.value)}
                        placeholder={t('factCheck.urlPlaceholder', 'Enter URL of article or social media post...')}
                        className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500"
                        disabled={isAnalyzing}
                      />
                    </div>
                    <div className="ml-2">
                      <FaLink className="text-gray-400" />
                    </div>
                  </div>
                )}
                
                {error && (
                  <div className="mt-3 text-red-600 text-sm">
                    {error}
                  </div>
                )}
                
                <div className="flex justify-end mt-4">
                  <motion.button
                    type="submit"
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="px-6 py-2 bg-primary-600 text-white rounded-lg flex items-center hover:bg-primary-700 transition disabled:bg-gray-400"
                    disabled={isAnalyzing || !input.trim()}
                  >
                    {isAnalyzing ? (
                      <>
                        <div className="mr-2 h-4 w-4 border-2 border-t-transparent border-white rounded-full animate-spin"></div>
                        {t('factCheck.analyzing', 'Analyzing...')}
                      </>
                    ) : (
                      <>
                        <FaCheckCircle className="mr-2" />
                        {t('factCheck.verifyButton', 'Verify Information')}
                      </>
                    )}
                  </motion.button>
                </div>
              </form>
            </div>
          </div>

          {/* Results section */}
          {result && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white rounded-xl shadow-md overflow-hidden"
            >
              <div className="bg-gray-50 px-6 py-4 border-b border-gray-200">
                <h2 className="text-xl font-bold text-gray-800">
                  {t('factCheck.resultsTitle', 'Analysis Results')}
                </h2>
              </div>
              
              <div className="p-6">
                {/* Overall verdict */}
                <div className={`p-4 rounded-lg mb-6 flex items-start ${
                  result.verdict === 'accurate' ? 'bg-green-50 text-green-800' :
                  result.verdict === 'inaccurate' ? 'bg-red-50 text-red-800' :
                  'bg-yellow-50 text-yellow-800'
                }`}>
                  <div className="mr-3 mt-1">
                    {result.verdict === 'accurate' ? (
                      <FaCheckCircle className="h-5 w-5 text-green-500" />
                    ) : result.verdict === 'inaccurate' ? (
                      <FaTimesCircle className="h-5 w-5 text-red-500" />
                    ) : (
                      <FaInfoCircle className="h-5 w-5 text-yellow-500" />
                    )}
                  </div>
                  <div>
                    <h3 className="font-bold text-lg mb-1">
                      {result.verdict === 'accurate' ? 
                        t('factCheck.verdicts.accurate', 'Information appears accurate') :
                        result.verdict === 'inaccurate' ? 
                        t('factCheck.verdicts.inaccurate', 'Information appears inaccurate') :
                        t('factCheck.verdicts.mixed', 'Information is partially accurate')
                      }
                    </h3>
                    <p>{result.summary}</p>
                  </div>
                </div>
                
                {/* Detailed analysis */}
                <div className="mb-6">
                  <h3 className="text-lg font-bold text-gray-800 mb-3">
                    {t('factCheck.detailedAnalysis', 'Detailed Analysis')}
                  </h3>
                  
                  {result.claims.map((claim: any, index: number) => (
                    <div key={index} className="border-b border-gray-200 py-3 last:border-0">
                      <div className="flex items-start">
                        <div className="mr-3 mt-1">
                          {claim.isAccurate ? (
                            <FaCheckCircle className="h-5 w-5 text-green-500" />
                          ) : (
                            <FaTimesCircle className="h-5 w-5 text-red-500" />
                          )}
                        </div>
                        <div>
                          <h4 className="font-medium text-gray-800">{claim.claim}</h4>
                          <p className="text-gray-600 mt-1">{claim.explanation}</p>
                          {claim.sources && claim.sources.length > 0 && (
                            <div className="mt-2">
                              <span className="text-sm font-medium text-gray-700">
                                {t('factCheck.sources', 'Sources')}:
                              </span>
                              <ul className="list-disc list-inside text-sm text-blue-600">
                                {claim.sources.map((source: string, i: number) => (
                                  <li key={i}><a href={source} target="_blank" rel="noopener noreferrer">{source}</a></li>
                                ))}
                              </ul>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                
                {/* Citation and advice */}
                <div className="bg-gray-50 p-4 rounded-lg text-sm text-gray-600">
                  <p className="mb-2 font-medium">{t('factCheck.disclaimer', 'Disclaimer:')}</p>
                  <p>{t('factCheck.disclaimerText', 'This analysis is AI-powered and should be used as a guide only. For medical or health concerns, always consult with qualified healthcare professionals.')}</p>
                </div>
              </div>
            </motion.div>
          )}
        </div>
      </div>
    </div>
  );
};

export default FactCheck;