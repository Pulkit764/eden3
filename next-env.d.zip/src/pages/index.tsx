import { NextPage } from 'next';
import { useTranslation } from 'react-i18next';
import { motion } from 'framer-motion';
import Link from 'next/link';
import Image from 'next/image';
import { FaUtensils, FaComment, FaMapMarkerAlt, FaLeaf } from 'react-icons/fa';

const Home: NextPage = () => {
  const { t } = useTranslation();

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative h-[80vh] flex items-center justify-center bg-gradient-to-br from-primary-600 to-primary-700 overflow-hidden">
        <div className="absolute inset-0 opacity-20">
          <Image 
            src="https://images.pexels.com/photos/1660030/pexels-photo-1660030.jpeg"
            alt="Healthy foods background"
            layout="fill"
            objectFit="cover"
            priority
          />
        </div>
        <div className="container mx-auto px-4 z-10 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="text-4xl md:text-6xl font-display font-bold text-white mb-4">
              {t('home.hero.title', 'EDEN')}
            </h1>
            <p className="text-xl md:text-2xl text-white mb-8 max-w-2xl mx-auto">
              {t('home.hero.subtitle', 'The AI-Powered Food System Navigator')}
            </p>
            <Link href="/chat" passHref>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-8 py-3 bg-accent-500 text-white font-bold rounded-lg shadow-lg hover:bg-accent-600 transition duration-300"
              >
                {t('home.hero.button', 'Start Your Journey')}
              </motion.button>
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-display font-bold text-center mb-12 text-gray-800">
            {t('home.features.title', 'How EDEN Helps You')}
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <FeatureCard 
              icon={<FaComment className="h-10 w-10 text-primary-600" />}
              title={t('home.features.aiCoach.title', 'AI Nutrition Coach')}
              description={t('home.features.aiCoach.description', 'Get personalized nutrition advice and answers to all your food-related questions.')}
              link="/chat"
            />
            
            <FeatureCard 
              icon={<FaUtensils className="h-10 w-10 text-primary-600" />}
              title={t('home.features.meals.title', 'Meal Suggestions')}
              description={t('home.features.meals.description', 'Discover meal ideas tailored to your preferences, budget, and dietary needs.')}
              link="/meals"
            />
            
            <FeatureCard 
              icon={<FaMapMarkerAlt className="h-10 w-10 text-primary-600" />}
              title={t('home.features.foodMap.title', 'Local Food Resources')}
              description={t('home.features.foodMap.description', 'Find affordable and healthy food options in your community.')}
              link="/map"
              comingSoon
            />
            
            <FeatureCard 
              icon={<FaLeaf className="h-10 w-10 text-primary-600" />}
              title={t('home.features.climate.title', 'Climate Impact')}
              description={t('home.features.climate.description', 'Learn how your food choices affect the environment and discover sustainable alternatives.')}
              link="/impact"
              comingSoon
            />
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-display font-bold text-center mb-12 text-gray-800">
            {t('home.howItWorks.title', 'How It Works')}
          </h2>
          
          <div className="max-w-4xl mx-auto">
            <div className="flex flex-col md:flex-row items-center mb-12">
              <div className="md:w-1/2 mb-8 md:mb-0 md:pr-8">
                <motion.div 
                  className="rounded-xl overflow-hidden shadow-lg relative h-64"
                  whileHover={{ y: -5, boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.25)' }}
                >
                  <Image 
                    src="https://images.pexels.com/photos/5926281/pexels-photo-5926281.jpeg"
                    alt="Create your profile"
                    layout="fill"
                    objectFit="cover"
                  />
                </motion.div>
              </div>
              <div className="md:w-1/2">
                <h3 className="text-2xl font-bold mb-4 text-gray-800">1. {t('home.howItWorks.step1.title', 'Create your profile')}</h3>
                <p className="text-gray-600">{t('home.howItWorks.step1.description', 'Answer a few questions about your dietary preferences, restrictions, and goals so EDEN can provide personalized recommendations.')}</p>
              </div>
            </div>
            
            <div className="flex flex-col md:flex-row-reverse items-center mb-12">
              <div className="md:w-1/2 mb-8 md:mb-0 md:pl-8">
                <motion.div 
                  className="rounded-xl overflow-hidden shadow-lg relative h-64"
                  whileHover={{ y: -5, boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.25)' }}
                >
                  <Image 
                    src="https://images.pexels.com/photos/3894378/pexels-photo-3894378.jpeg"
                    alt="Chat with EDEN"
                    layout="fill"
                    objectFit="cover"
                  />
                </motion.div>
              </div>
              <div className="md:w-1/2">
                <h3 className="text-2xl font-bold mb-4 text-gray-800">2. {t('home.howItWorks.step2.title', 'Chat with EDEN')}</h3>
                <p className="text-gray-600">{t('home.howItWorks.step2.description', 'Ask questions, get meal ideas, and receive guidance on nutrition, ingredients, and cooking techniques.')}</p>
              </div>
            </div>
            
            <div className="flex flex-col md:flex-row items-center">
              <div className="md:w-1/2 mb-8 md:mb-0 md:pr-8">
                <motion.div 
                  className="rounded-xl overflow-hidden shadow-lg relative h-64"
                  whileHover={{ y: -5, boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.25)' }}
                >
                  <Image 
                    src="https://images.pexels.com/photos/8844387/pexels-photo-8844387.jpeg"
                    alt="Discover and adapt"
                    layout="fill"
                    objectFit="cover"
                  />
                </motion.div>
              </div>
              <div className="md:w-1/2">
                <h3 className="text-2xl font-bold mb-4 text-gray-800">3. {t('home.howItWorks.step3.title', 'Discover and adapt')}</h3>
                <p className="text-gray-600">{t('home.howItWorks.step3.description', 'Explore personalized meal suggestions that adapt to your preferences, budget, and available ingredients.')}</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-secondary-500 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-display font-bold mb-6">
            {t('home.cta.title', 'Ready to transform your relationship with food?')}
          </h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            {t('home.cta.description', 'Join EDEN today and discover a more personalized, sustainable, and healthy approach to eating.')}
          </p>
          <Link href="/signup" passHref>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="px-8 py-3 bg-white text-secondary-600 font-bold rounded-lg shadow-lg hover:bg-gray-100 transition duration-300"
            >
              {t('home.cta.button', 'Get Started For Free')}
            </motion.button>
          </Link>
        </div>
      </section>
    </div>
  );
};

interface FeatureCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  link: string;
  comingSoon?: boolean;
}

const FeatureCard = ({ icon, title, description, link, comingSoon }: FeatureCardProps) => {
  return (
    <motion.div
      whileHover={{ y: -5 }}
      className="bg-white p-6 rounded-xl shadow-md flex flex-col items-center text-center"
    >
      <div className="mb-4">{icon}</div>
      <h3 className="text-xl font-bold mb-2 text-gray-800">{title}</h3>
      <p className="text-gray-600 mb-4">{description}</p>
      {comingSoon ? (
        <span className="px-4 py-1 bg-gray-200 text-gray-600 rounded-full text-sm">Coming Soon</span>
      ) : (
        <Link href={link} passHref>
          <button className="text-primary-600 font-semibold hover:text-primary-700 transition">
            Learn More →
          </button>
        </Link>
      )}
    </motion.div>
  );
};

export default Home;