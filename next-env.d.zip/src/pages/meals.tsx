import { NextPage } from 'next';
import { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { motion } from 'framer-motion';
import { FaHeart, FaHeartBroken, FaLeaf, FaRegClock, FaDollarSign } from 'react-icons/fa';
import Image from 'next/image';
import useUserStore from '../store/userStore';
import { getMealSuggestions } from '../services/mealService';
import MealFilters from '../components/meals/MealFilters';
import NutritionBadge from '../components/meals/NutritionBadge';

const Meals: NextPage = () => {
  const { t } = useTranslation();
  const { userProfile } = useUserStore();
  
  const [meals, setMeals] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({
    mealType: 'all',
    diet: userProfile?.dietaryPreferences || 'all',
    maxTime: 60,
    maxCost: 3, // 1-3 scale
    includeIngredients: [],
    excludeIngredients: []
  });

  useEffect(() => {
    fetchMeals();
  }, [filters, userProfile]);

  const fetchMeals = async () => {
    setLoading(true);
    try {
      const mealData = await getMealSuggestions(userProfile, filters);
      setMeals(mealData);
    } catch (error) {
      console.error('Error fetching meals:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleFilterChange = (newFilters: any) => {
    setFilters({ ...filters, ...newFilters });
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-5xl mx-auto">
          <h1 className="text-3xl font-bold text-gray-800 mb-2">
            {t('meals.title', 'Personalized Meal Suggestions')}
          </h1>
          <p className="text-gray-600 mb-8">
            {t('meals.subtitle', 'Discover meal ideas tailored to your preferences, budget, and dietary needs.')}
          </p>

          {/* Filters */}
          <MealFilters 
            filters={filters} 
            onChange={handleFilterChange} 
            userProfile={userProfile}
          />

          {/* Meal Cards */}
          {loading ? (
            <div className="flex justify-center items-center h-64">
              <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-600"></div>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-8">
              {meals.map((meal, index) => (
                <MealCard key={index} meal={meal} />
              ))}
              
              {meals.length === 0 && (
                <div className="col-span-3 text-center py-12">
                  <p className="text-xl text-gray-500">
                    {t('meals.noResults', 'No meal suggestions found. Try adjusting your filters.')}
                  </p>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

interface MealCardProps {
  meal: {
    id: string;
    name: string;
    image: string;
    description: string;
    prepTime: number;
    costLevel: number;
    ingredients: string[];
    nutritionInfo: {
      calories: number;
      protein: number;
      carbs: number;
      fat: number;
    };
    sustainability: number; // 1-5 scale
    dietaryTags: string[];
  };
}

const MealCard = ({ meal }: MealCardProps) => {
  const { t } = useTranslation();
  const [isSaved, setIsSaved] = useState(false);

  const toggleSave = () => {
    setIsSaved(!isSaved);
    // Implementation for saving meal to user favorites would go here
  };

  // Format cost level as dollar signs
  const costDisplay = [...Array(meal.costLevel)].map((_, i) => (
    <FaDollarSign key={i} className="inline" />
  ));

  return (
    <motion.div
      whileHover={{ y: -5 }}
      className="bg-white rounded-xl shadow-md overflow-hidden"
    >
      <div className="relative h-48">
        <Image
          src={meal.image || "https://images.pexels.com/photos/1640774/pexels-photo-1640774.jpeg"}
          alt={meal.name}
          layout="fill"
          objectFit="cover"
        />
        <button
          onClick={toggleSave}
          className="absolute top-2 right-2 p-2 bg-white rounded-full shadow-md text-gray-700 hover:text-primary-600 transition"
        >
          {isSaved ? <FaHeart className="text-primary-600" /> : <FaHeartBroken />}
        </button>
        
        {/* Sustainability badge */}
        <div className="absolute bottom-2 left-2 bg-white px-2 py-1 rounded-full text-xs flex items-center shadow-md">
          <FaLeaf className="text-green-500 mr-1" />
          <span className="font-medium">
            {[...Array(5)].map((_, i) => (
              <span key={i} className={i < meal.sustainability ? "text-green-500" : "text-gray-300"}>●</span>
            ))}
          </span>
        </div>
      </div>
      
      <div className="p-4">
        <div className="flex justify-between items-start mb-2">
          <h3 className="text-lg font-bold text-gray-800">{meal.name}</h3>
          <div className="flex items-center text-sm text-gray-500">
            <FaRegClock className="mr-1" />
            <span>{meal.prepTime} min</span>
          </div>
        </div>
        
        <p className="text-gray-600 text-sm mb-4 line-clamp-2">{meal.description}</p>
        
        {/* Tags */}
        <div className="flex flex-wrap gap-1 mb-3">
          {meal.dietaryTags.map((tag, index) => (
            <span 
              key={index}
              className="px-2 py-1 bg-primary-100 text-primary-700 rounded-full text-xs font-medium"
            >
              {tag}
            </span>
          ))}
        </div>
        
        {/* Cost indicator */}
        <div className="text-gray-500 text-sm mb-3">
          {t('meals.cost', 'Cost')}: <span className="text-amber-500">{costDisplay}</span>
        </div>
        
        {/* Nutrition info */}
        <div className="flex justify-between mb-3">
          <NutritionBadge 
            label={t('meals.calories', 'Cal')} 
            value={meal.nutritionInfo.calories} 
            unit="kcal"
          />
          <NutritionBadge 
            label={t('meals.protein', 'Protein')} 
            value={meal.nutritionInfo.protein} 
            unit="g"
          />
          <NutritionBadge 
            label={t('meals.carbs', 'Carbs')} 
            value={meal.nutritionInfo.carbs} 
            unit="g"
          />
          <NutritionBadge 
            label={t('meals.fat', 'Fat')} 
            value={meal.nutritionInfo.fat} 
            unit="g"
          />
        </div>
        
        <button className="w-full py-2 text-center text-primary-600 font-medium border border-primary-600 rounded-lg hover:bg-primary-50 transition">
          {t('meals.viewRecipe', 'View Recipe')}
        </button>
      </div>
    </motion.div>
  );
};

export default Meals;