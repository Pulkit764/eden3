import { NextPage } from 'next';
import { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { useForm } from 'react-hook-form';
import { motion } from 'framer-motion';
import { FaUserCircle, FaSave, FaUndo } from 'react-icons/fa';
import useUserStore from '../store/userStore';
import { updateUserProfile } from '../services/userService';

const Profile: NextPage = () => {
  const { t } = useTranslation();
  const { userProfile, setUserProfile } = useUserStore();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [message, setMessage] = useState({ type: '', text: '' });
  
  const { register, handleSubmit, reset, formState: { errors } } = useForm({
    defaultValues: userProfile || {}
  });

  useEffect(() => {
    if (userProfile) {
      reset(userProfile);
    }
  }, [userProfile, reset]);

  const onSubmit = async (data: any) => {
    setIsSubmitting(true);
    setMessage({ type: '', text: '' });
    
    try {
      await updateUserProfile(data);
      setUserProfile(data);
      setMessage({ 
        type: 'success', 
        text: t('profile.successMessage', 'Profile updated successfully!') 
      });
    } catch (error) {
      console.error('Error updating profile:', error);
      setMessage({ 
        type: 'error', 
        text: t('profile.errorMessage', 'There was an error updating your profile. Please try again.') 
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-3xl mx-auto bg-white rounded-xl shadow-md overflow-hidden">
          <div className="bg-primary-600 px-6 py-4">
            <h1 className="text-xl font-bold text-white">
              {t('profile.title', 'Your Profile')}
            </h1>
            <p className="text-primary-100 text-sm">
              {t('profile.subtitle', 'Customize your preferences for better recommendations')}
            </p>
          </div>
          
          <form onSubmit={handleSubmit(onSubmit)} className="p-6">
            {/* Avatar and basic info */}
            <div className="flex flex-col md:flex-row items-center mb-8">
              <div className="mb-4 md:mb-0 md:mr-6">
                <div className="w-24 h-24 rounded-full bg-gray-200 flex items-center justify-center text-gray-400">
                  <FaUserCircle className="w-full h-full" />
                </div>
              </div>
              
              <div className="flex-grow">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      {t('profile.name', 'Name')}
                    </label>
                    <input
                      type="text"
                      {...register('name', { required: true })}
                      className={`w-full p-2 border rounded-lg ${errors.name ? 'border-red-500' : 'border-gray-300'}`}
                    />
                    {errors.name && (
                      <p className="mt-1 text-sm text-red-600">
                        {t('profile.nameRequired', 'Name is required')}
                      </p>
                    )}
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      {t('profile.email', 'Email')}
                    </label>
                    <input
                      type="email"
                      {...register('email', { 
                        required: true,
                        pattern: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i
                      })}
                      className={`w-full p-2 border rounded-lg ${errors.email ? 'border-red-500' : 'border-gray-300'}`}
                    />
                    {errors.email?.type === 'required' && (
                      <p className="mt-1 text-sm text-red-600">
                        {t('profile.emailRequired', 'Email is required')}
                      </p>
                    )}
                    {errors.email?.type === 'pattern' && (
                      <p className="mt-1 text-sm text-red-600">
                        {t('profile.emailInvalid', 'Please enter a valid email')}
                      </p>
                    )}
                  </div>
                </div>
              </div>
            </div>
            
            <div className="mb-6">
              <h2 className="text-lg font-semibold text-gray-800 mb-4">
                {t('profile.dietaryPreferences', 'Dietary Preferences')}
              </h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    {t('profile.dietType', 'Diet Type')}
                  </label>
                  <select
                    {...register('dietaryPreferences')}
                    className="w-full p-2 border border-gray-300 rounded-lg"
                  >
                    <option value="omnivore">{t('profile.dietTypes.omnivore', 'Omnivore')}</option>
                    <option value="vegetarian">{t('profile.dietTypes.vegetarian', 'Vegetarian')}</option>
                    <option value="vegan">{t('profile.dietTypes.vegan', 'Vegan')}</option>
                    <option value="pescatarian">{t('profile.dietTypes.pescatarian', 'Pescatarian')}</option>
                    <option value="paleo">{t('profile.dietTypes.paleo', 'Paleo')}</option>
                    <option value="keto">{t('profile.dietTypes.keto', 'Keto')}</option>
                    <option value="mediterranean">{t('profile.dietTypes.mediterranean', 'Mediterranean')}</option>
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    {t('profile.cookingSkill', 'Cooking Skill Level')}
                  </label>
                  <select
                    {...register('cookingSkill')}
                    className="w-full p-2 border border-gray-300 rounded-lg"
                  >
                    <option value="beginner">{t('profile.skillLevels.beginner', 'Beginner')}</option>
                    <option value="intermediate">{t('profile.skillLevels.intermediate', 'Intermediate')}</option>
                    <option value="advanced">{t('profile.skillLevels.advanced', 'Advanced')}</option>
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    {t('profile.budgetLevel', 'Budget Level')}
                  </label>
                  <select
                    {...register('budgetLevel')}
                    className="w-full p-2 border border-gray-300 rounded-lg"
                  >
                    <option value="low">{t('profile.budgetLevels.low', 'Economy')}</option>
                    <option value="medium">{t('profile.budgetLevels.medium', 'Moderate')}</option>
                    <option value="high">{t('profile.budgetLevels.high', 'Premium')}</option>
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    {t('profile.householdSize', 'Household Size')}
                  </label>
                  <input
                    type="number"
                    min="1"
                    max="10"
                    {...register('householdSize', { 
                      required: true,
                      min: 1,
                      max: 10
                    })}
                    className={`w-full p-2 border rounded-lg ${errors.householdSize ? 'border-red-500' : 'border-gray-300'}`}
                  />
                  {errors.householdSize && (
                    <p className="mt-1 text-sm text-red-600">
                      {t('profile.householdSizeError', 'Please enter a valid household size (1-10)')}
                    </p>
                  )}
                </div>
              </div>
              
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  {t('profile.allergies', 'Allergies or Intolerances')}
                </label>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {['dairy', 'eggs', 'nuts', 'peanuts', 'wheat', 'gluten', 'soy', 'fish', 'shellfish'].map((allergy) => (
                    <div key={allergy} className="flex items-center">
                      <input
                        type="checkbox"
                        id={`allergy-${allergy}`}
                        value={allergy}
                        {...register('allergies')}
                        className="h-4 w-4 text-primary-600 border-gray-300 rounded focus:ring-primary-500"
                      />
                      <label htmlFor={`allergy-${allergy}`} className="ml-2 text-sm text-gray-700">
                        {t(`profile.allergyTypes.${allergy}`, allergy)}
                      </label>
                    </div>
                  ))}
                </div>
              </div>
              
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  {t('profile.healthConditions', 'Health Conditions')}
                </label>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {['diabetes', 'hypertension', 'heart_disease', 'cholesterol'].map((condition) => (
                    <div key={condition} className="flex items-center">
                      <input
                        type="checkbox"
                        id={`condition-${condition}`}
                        value={condition}
                        {...register('healthConditions')}
                        className="h-4 w-4 text-primary-600 border-gray-300 rounded focus:ring-primary-500"
                      />
                      <label htmlFor={`condition-${condition}`} className="ml-2 text-sm text-gray-700">
                        {t(`profile.conditionTypes.${condition}`, condition.replace('_', ' '))}
                      </label>
                    </div>
                  ))}
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  {t('profile.sustainabilityPreference', 'Sustainability Preference')}
                </label>
                <select
                  {...register('sustainabilityPreference')}
                  className="w-full p-2 border border-gray-300 rounded-lg"
                >
                  <option value="low">{t('profile.sustainabilityLevels.low', 'Not a priority')}</option>
                  <option value="medium">{t('profile.sustainabilityLevels.medium', 'Somewhat important')}</option>
                  <option value="high">{t('profile.sustainabilityLevels.high', 'Very important')}</option>
                </select>
              </div>
            </div>
            
            {/* Message display */}
            {message.text && (
              <div className={`p-3 rounded mb-4 ${message.type === 'success' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                {message.text}
              </div>
            )}
            
            {/* Form actions */}
            <div className="flex justify-end space-x-4">
              <button
                type="button"
                onClick={() => reset(userProfile)}
                className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 flex items-center"
              >
                <FaUndo className="mr-2" />
                {t('profile.resetButton', 'Reset')}
              </button>
              
              <motion.button
                type="submit"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-4 py-2 bg-primary-600 text-white rounded-lg flex items-center disabled:bg-gray-400"
                disabled={isSubmitting}
              >
                {isSubmitting ? (
                  <div className="mr-2 h-4 w-4 border-2 border-t-transparent border-white rounded-full animate-spin"></div>
                ) : (
                  <FaSave className="mr-2" />
                )}
                {t('profile.saveButton', 'Save Changes')}
              </motion.button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Profile;