import { NextPage } from 'next';
import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useForm } from 'react-hook-form';
import { motion } from 'framer-motion';
import Link from 'next/link';
import { FaUser, FaEnvelope, FaLock, FaArrowRight } from 'react-icons/fa';
import { signup } from '../services/authService';
import { useRouter } from 'next/router';

const Signup: NextPage = () => {
  const { t } = useTranslation();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const router = useRouter();
  
  const { register, handleSubmit, formState: { errors }, watch } = useForm();
  const password = watch('password', '');

  const onSubmit = async (data: any) => {
    setIsSubmitting(true);
    setErrorMessage('');
    
    try {
      await signup(data);
      // Redirect to profile completion page after successful signup
      router.push('/profile');
    } catch (error: any) {
      console.error('Signup error:', error);
      setErrorMessage(error.message || t('signup.genericError', 'An error occurred during sign up. Please try again.'));
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8">
        <div className="text-center">
          <h1 className="text-3xl font-bold text-gray-800">
            {t('signup.title', 'Join EDEN')}
          </h1>
          <p className="mt-2 text-gray-600">
            {t('signup.subtitle', 'Create your account to get personalized nutrition guidance')}
          </p>
        </div>
        
        <div className="bg-white p-8 rounded-xl shadow-md">
          {errorMessage && (
            <div className="mb-4 p-3 bg-red-100 text-red-700 rounded-lg">
              {errorMessage}
            </div>
          )}
          
          <form className="space-y-6" onSubmit={handleSubmit(onSubmit)}>
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                {t('signup.name', 'Full Name')}
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <FaUser className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  id="name"
                  type="text"
                  {...register('name', { required: true })}
                  className={`block w-full pl-10 pr-3 py-2 border ${errors.name ? 'border-red-500' : 'border-gray-300'} rounded-lg focus:outline-none focus:ring-primary-500 focus:border-primary-500`}
                />
              </div>
              {errors.name && (
                <p className="mt-1 text-sm text-red-600">
                  {t('signup.nameRequired', 'Name is required')}
                </p>
              )}
            </div>
            
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                {t('signup.email', 'Email Address')}
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <FaEnvelope className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  id="email"
                  type="email"
                  {...register('email', { 
                    required: true,
                    pattern: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i
                  })}
                  className={`block w-full pl-10 pr-3 py-2 border ${errors.email ? 'border-red-500' : 'border-gray-300'} rounded-lg focus:outline-none focus:ring-primary-500 focus:border-primary-500`}
                />
              </div>
              {errors.email?.type === 'required' && (
                <p className="mt-1 text-sm text-red-600">
                  {t('signup.emailRequired', 'Email is required')}
                </p>
              )}
              {errors.email?.type === 'pattern' && (
                <p className="mt-1 text-sm text-red-600">
                  {t('signup.emailInvalid', 'Please enter a valid email')}
                </p>
              )}
            </div>
            
            <div>
              <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-1">
                {t('signup.password', 'Password')}
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <FaLock className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  id="password"
                  type="password"
                  {...register('password', { 
                    required: true,
                    minLength: 8
                  })}
                  className={`block w-full pl-10 pr-3 py-2 border ${errors.password ? 'border-red-500' : 'border-gray-300'} rounded-lg focus:outline-none focus:ring-primary-500 focus:border-primary-500`}
                />
              </div>
              {errors.password?.type === 'required' && (
                <p className="mt-1 text-sm text-red-600">
                  {t('signup.passwordRequired', 'Password is required')}
                </p>
              )}
              {errors.password?.type === 'minLength' && (
                <p className="mt-1 text-sm text-red-600">
                  {t('signup.passwordLength', 'Password must be at least 8 characters')}
                </p>
              )}
            </div>
            
            <div>
              <label htmlFor="confirmPassword" className="block text-sm font-medium text-gray-700 mb-1">
                {t('signup.confirmPassword', 'Confirm Password')}
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <FaLock className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  id="confirmPassword"
                  type="password"
                  {...register('confirmPassword', { 
                    required: true,
                    validate: value => value === password || t('signup.passwordMatch', 'Passwords do not match')
                  })}
                  className={`block w-full pl-10 pr-3 py-2 border ${errors.confirmPassword ? 'border-red-500' : 'border-gray-300'} rounded-lg focus:outline-none focus:ring-primary-500 focus:border-primary-500`}
                />
              </div>
              {errors.confirmPassword && (
                <p className="mt-1 text-sm text-red-600">
                  {errors.confirmPassword.message as string || t('signup.confirmPasswordRequired', 'Please confirm your password')}
                </p>
              )}
            </div>
            
            <div className="flex items-center">
              <input
                id="terms"
                type="checkbox"
                {...register('terms', { required: true })}
                className="h-4 w-4 text-primary-600 border-gray-300 rounded focus:ring-primary-500"
              />
              <label htmlFor="terms" className="ml-2 block text-sm text-gray-700">
                {t('signup.termsAgreement', 'I agree to the')} <a href="/terms" className="text-primary-600 hover:text-primary-800">{t('signup.terms', 'Terms of Service')}</a> {t('signup.and', 'and')} <a href="/privacy" className="text-primary-600 hover:text-primary-800">{t('signup.privacy', 'Privacy Policy')}</a>
              </label>
            </div>
            {errors.terms && (
              <p className="mt-1 text-sm text-red-600">
                {t('signup.termsRequired', 'You must agree to the terms and privacy policy')}
              </p>
            )}
            
            <div>
              <motion.button
                type="submit"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="group relative w-full flex justify-center py-2 px-4 border border-transparent rounded-lg text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 disabled:bg-gray-400"
                disabled={isSubmitting}
              >
                {isSubmitting ? (
                  <div className="h-5 w-5 border-2 border-t-transparent border-white rounded-full animate-spin"></div>
                ) : (
                  <>
                    <span className="absolute right-4 inset-y-0 flex items-center">
                      <FaArrowRight className="h-5 w-5 text-white group-hover:translate-x-1 transition-transform" />
                    </span>
                    {t('signup.createAccount', 'Create Account')}
                  </>
                )}
              </motion.button>
            </div>
          </form>
          
          <div className="mt-6 text-center">
            <p className="text-sm text-gray-600">
              {t('signup.alreadyHaveAccount', 'Already have an account?')} <Link href="/login" className="text-primary-600 hover:text-primary-800 font-medium">{t('signup.login', 'Log in')}</Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Signup;