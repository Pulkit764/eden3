// Mock authentication service for development

// Mock user data storage (would use a real database in production)
let mockUsers: any[] = [];
let currentUser: any = null;

// Simulate user signup
export const signup = async (userData: any): Promise<any> => {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  // Check if email already exists
  const existingUser = mockUsers.find(user => user.email === userData.email);
  if (existingUser) {
    throw new Error('Email already in use');
  }
  
  // Create new user
  const newUser = {
    id: `user-${Date.now()}`,
    name: userData.name,
    email: userData.email,
    // In a real app, we would never store passwords like this
    // This is just for the mock implementation
    password: userData.password, 
    createdAt: new Date().toISOString()
  };
  
  // Store user
  mockUsers.push(newUser);
  
  // Set as current user
  currentUser = { ...newUser };
  delete currentUser.password; // Don't expose password
  
  // Save to local storage for persistence across page refreshes
  if (typeof window !== 'undefined') {
    localStorage.setItem('eden_current_user', JSON.stringify(currentUser));
  }
  
  return currentUser;
};

// Simulate user login
export const login = async (email: string, password: string): Promise<any> => {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  // Find user
  const user = mockUsers.find(u => u.email === email && u.password === password);
  
  if (!user) {
    throw new Error('Invalid email or password');
  }
  
  // Set as current user
  currentUser = { ...user };
  delete currentUser.password; // Don't expose password
  
  // Save to local storage
  if (typeof window !== 'undefined') {
    localStorage.setItem('eden_current_user', JSON.stringify(currentUser));
  }
  
  return currentUser;
};

// Simulate user logout
export const logout = async (): Promise<void> => {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 500));
  
  // Clear current user
  currentUser = null;
  
  // Remove from local storage
  if (typeof window !== 'undefined') {
    localStorage.removeItem('eden_current_user');
  }
};

// Check if user is authenticated
export const isAuthenticated = (): boolean => {
  if (currentUser) return true;
  
  // Check local storage for persistence
  if (typeof window !== 'undefined') {
    const storedUser = localStorage.getItem('eden_current_user');
    if (storedUser) {
      currentUser = JSON.parse(storedUser);
      return true;
    }
  }
  
  return false;
};

// Get current user
export const getCurrentUser = (): any => {
  if (currentUser) return currentUser;
  
  // Check local storage
  if (typeof window !== 'undefined') {
    const storedUser = localStorage.getItem('eden_current_user');
    if (storedUser) {
      currentUser = JSON.parse(storedUser);
      return currentUser;
    }
  }
  
  return null;
};