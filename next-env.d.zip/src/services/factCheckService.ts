// Mock data for development - in production would use actual API calls

// Sample fact-check results to use in development
const mockFactCheckResults = [
  {
    verdict: 'accurate',
    summary: 'The information provided appears to be accurate based on current nutritional science. The claims align with established research and dietary guidelines.',
    claims: [
      {
        claim: 'Fruits and vegetables are important sources of dietary fiber, vitamins, and minerals.',
        isAccurate: true,
        explanation: 'This is well-established in nutritional science. Fruits and vegetables are indeed excellent sources of fiber, vitamins, minerals, and phytonutrients essential for health.',
        sources: ['https://www.cdc.gov/nutrition/resources-publications/benefits-of-healthy-eating.html']
      },
      {
        claim: 'Including a variety of colorful produce in your diet helps ensure adequate nutrient intake.',
        isAccurate: true,
        explanation: 'Different colored fruits and vegetables contain different phytonutrients and antioxidants, so eating a variety ensures a wide range of beneficial compounds.',
        sources: ['https://www.hsph.harvard.edu/nutritionsource/what-should-you-eat/vegetables-and-fruits/']
      }
    ]
  },
  {
    verdict: 'inaccurate',
    summary: 'The content contains several inaccurate claims that are not supported by scientific evidence and contradict established nutritional guidelines.',
    claims: [
      {
        claim: 'Drinking celery juice can cure all digestive issues and chronic diseases.',
        isAccurate: false,
        explanation: 'There is no scientific evidence that celery juice can cure digestive issues or chronic diseases. While celery is nutritious, no single food has curative powers for complex health conditions.',
        sources: ['https://www.nccih.nih.gov/health/using-dietary-supplements-wisely']
      },
      {
        claim: 'All carbohydrates should be avoided for optimal health.',
        isAccurate: false,
        explanation: 'Carbohydrates are a macronutrient that provides essential energy. While reducing refined carbs may benefit some people, whole food sources of carbohydrates like fruits, vegetables, and whole grains provide important nutrients and fiber.',
        sources: ['https://www.mayoclinic.org/healthy-lifestyle/nutrition-and-healthy-eating/in-depth/carbohydrates/art-20045705']
      }
    ]
  },
  {
    verdict: 'mixed',
    summary: 'The information contains a mix of accurate and inaccurate claims. While some points are supported by evidence, others are exaggerated or lack scientific backing.',
    claims: [
      {
        claim: 'Intermittent fasting can help with weight management for some people.',
        isAccurate: true,
        explanation: 'Research does suggest that intermittent fasting can be an effective approach to weight management for some individuals. However, results vary and it may not be suitable for everyone.',
        sources: ['https://www.nejm.org/doi/full/10.1056/NEJMra1905136']
      },
      {
        claim: 'Intermittent fasting reverses aging and prevents all chronic diseases.',
        isAccurate: false,
        explanation: 'This claim is exaggerated. While some research in animals suggests potential longevity benefits, claiming it reverses aging or prevents all chronic diseases in humans is not supported by current evidence.',
        sources: ['https://www.niddk.nih.gov/health-information/weight-management/adult-overweight-obesity/health-risks']
      }
    ]
  }
];

// Define interface for fact check input
interface FactCheckInput {
  text?: string;
  url?: string;
}

// Generate a fact-check analysis
export const checkFoodInformation = async (
  input: string,
  mode: 'text' | 'url' = 'text'
): Promise<any> => {
  try {
    // Simulate network delay
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // In production, this would call an analysis API
    // For development, return a random mock result
    
    // Randomize the result for demo purposes
    const randomIndex = Math.floor(Math.random() * mockFactCheckResults.length);
    const result = { ...mockFactCheckResults[randomIndex] };
    
    // If the input contains certain keywords, we can make the response more relevant
    const lowercaseInput = input.toLowerCase();
    
    if (lowercaseInput.includes('sugar') || lowercaseInput.includes('sweetener')) {
      result.claims = [
        {
          claim: 'All sugar is harmful and should be completely eliminated from the diet.',
          isAccurate: false,
          explanation: 'While excessive added sugar consumption is associated with health risks, not all sugar is harmful. Natural sugars in fruits come with fiber, vitamins, and minerals. Complete elimination is unnecessary for most people.',
          sources: ['https://www.heart.org/en/healthy-living/healthy-eating/eat-smart/sugar/sugar-101']
        },
        {
          claim: 'Artificial sweeteners are safer alternatives to sugar.',
          isAccurate: false,
          explanation: 'The safety and potential health effects of artificial sweeteners are still being studied. Some research suggests they may affect gut bacteria and metabolism. They aren\'t necessarily healthier alternatives for everyone.',
          sources: ['https://www.hsph.harvard.edu/nutritionsource/healthy-drinks/artificial-sweeteners/']
        }
      ];
      
      result.summary = 'The claims about sugar and sweeteners in this content contain inaccuracies and oversimplifications that don\'t align with current nutritional understanding.';
      result.verdict = 'inaccurate';
    } else if (lowercaseInput.includes('protein') || lowercaseInput.includes('meat')) {
      result.claims = [
        {
          claim: 'Plant proteins can provide all essential amino acids.',
          isAccurate: true,
          explanation: 'A varied diet of plant proteins (legumes, grains, nuts, seeds) can provide all essential amino acids. While some plant foods are low in certain amino acids, eating a diverse mix ensures complete protein intake.',
          sources: ['https://www.health.harvard.edu/blog/with-a-little-planning-vegan-diets-can-be-a-healthful-choice-2020020618766']
        },
        {
          claim: 'Red meat is always harmful to health.',
          isAccurate: false,
          explanation: 'The health effects of red meat depend on multiple factors including processing, cooking methods, and overall diet quality. Unprocessed red meat in moderation can be part of a healthy diet for many people.',
          sources: ['https://www.health.harvard.edu/staying-healthy/whats-the-beef-with-red-meat']
        }
      ];
      
      result.summary = 'The information about protein sources contains both accurate and inaccurate statements. The nutritional value of different protein sources is more nuanced than presented.';
      result.verdict = 'mixed';
    }
    
    return result;
  } catch (error) {
    console.error('Error in fact checking:', error);
    throw new Error('Failed to analyze the information');
  }
};