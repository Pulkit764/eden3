// Mock data for development - in production would use actual API calls

// Sample meal suggestions to use in development
const mockMeals = [
  {
    id: "meal-1",
    name: "Mediterranean Chickpea Bowl",
    image: "https://images.pexels.com/photos/1640774/pexels-photo-1640774.jpeg",
    description: "A nutritious bowl featuring chickpeas, cucumber, tomatoes, feta cheese, and olives on a bed of quinoa, drizzled with olive oil and lemon juice.",
    prepTime: 20,
    costLevel: 2,
    ingredients: [
      "1 cup cooked quinoa",
      "1 can chickpeas, drained and rinsed",
      "1 cucumber, diced",
      "1 cup cherry tomatoes, halved",
      "1/4 cup feta cheese, crumbled",
      "2 tbsp olives, sliced",
      "2 tbsp olive oil",
      "1 lemon, juiced",
      "Fresh herbs (mint, parsley)"
    ],
    nutritionInfo: {
      calories: 420,
      protein: 15,
      carbs: 52,
      fat: 18
    },
    sustainability: 4,
    dietaryTags: ["Vegetarian", "Mediterranean", "High Fiber"]
  },
  {
    id: "meal-2",
    name: "Lentil & Sweet Potato Curry",
    image: "https://images.pexels.com/photos/3386854/pexels-photo-3386854.jpeg",
    description: "A hearty and flavorful curry combining red lentils and sweet potatoes in a rich coconut milk base with aromatic spices.",
    prepTime: 35,
    costLevel: 1,
    ingredients: [
      "1 cup red lentils, rinsed",
      "2 medium sweet potatoes, diced",
      "1 onion, chopped",
      "3 cloves garlic, minced",
      "1 tbsp ginger, grated",
      "1 can coconut milk",
      "2 cups vegetable broth",
      "2 tbsp curry powder",
      "1 tsp turmeric",
      "Fresh cilantro for garnish"
    ],
    nutritionInfo: {
      calories: 380,
      protein: 12,
      carbs: 58,
      fat: 14
    },
    sustainability: 5,
    dietaryTags: ["Vegan", "Gluten-Free", "Budget-Friendly"]
  },
  {
    id: "meal-3",
    name: "Grilled Salmon with Avocado Salsa",
    image: "https://images.pexels.com/photos/262959/pexels-photo-262959.jpeg",
    description: "Perfectly grilled salmon topped with a fresh avocado salsa, served with a side of roasted asparagus and brown rice.",
    prepTime: 25,
    costLevel: 3,
    ingredients: [
      "4 salmon fillets (4-6 oz each)",
      "2 avocados, diced",
      "1 red onion, finely chopped",
      "1 lime, juiced",
      "1 bunch asparagus, trimmed",
      "1 cup brown rice, cooked",
      "Olive oil, salt, pepper to taste",
      "Fresh cilantro, chopped"
    ],
    nutritionInfo: {
      calories: 520,
      protein: 38,
      carbs: 35,
      fat: 26
    },
    sustainability: 3,
    dietaryTags: ["High-Protein", "Gluten-Free", "Omega-3 Rich"]
  },
  {
    id: "meal-4",
    name: "Quick Vegetable Stir-Fry",
    image: "https://images.pexels.com/photos/1099680/pexels-photo-1099680.jpeg",
    description: "A colorful and quick veggie stir-fry with tofu, broccoli, bell peppers, and snap peas in a ginger-garlic sauce.",
    prepTime: 15,
    costLevel: 2,
    ingredients: [
      "1 block firm tofu, cubed",
      "2 cups broccoli florets",
      "1 red bell pepper, sliced",
      "1 cup snap peas",
      "2 carrots, sliced",
      "3 cloves garlic, minced",
      "1 tbsp ginger, grated",
      "3 tbsp soy sauce or tamari",
      "1 tbsp sesame oil",
      "2 green onions, sliced"
    ],
    nutritionInfo: {
      calories: 320,
      protein: 18,
      carbs: 30,
      fat: 15
    },
    sustainability: 4,
    dietaryTags: ["Vegan", "Quick", "Vegetable-Rich"]
  },
  {
    id: "meal-5",
    name: "Black Bean & Quinoa Burrito Bowl",
    image: "https://images.pexels.com/photos/5737247/pexels-photo-5737247.jpeg",
    description: "A satisfying burrito bowl with black beans, quinoa, corn, avocado, and a zesty lime dressing.",
    prepTime: 20,
    costLevel: 1,
    ingredients: [
      "1 can black beans, drained and rinsed",
      "1 cup cooked quinoa",
      "1 cup corn kernels",
      "1 avocado, diced",
      "1 cup cherry tomatoes, halved",
      "1/4 cup red onion, diced",
      "1 lime, juiced",
      "2 tbsp olive oil",
      "1 tsp cumin",
      "Fresh cilantro, chopped"
    ],
    nutritionInfo: {
      calories: 420,
      protein: 15,
      carbs: 58,
      fat: 16
    },
    sustainability: 5,
    dietaryTags: ["Vegetarian", "High-Fiber", "Budget-Friendly"]
  },
  {
    id: "meal-6",
    name: "Baked Herb Chicken with Roasted Vegetables",
    image: "https://images.pexels.com/photos/2338407/pexels-photo-2338407.jpeg",
    description: "Herb-marinated chicken breast baked with seasonal vegetables for a simple and satisfying dinner.",
    prepTime: 45,
    costLevel: 2,
    ingredients: [
      "4 chicken breasts",
      "2 cups mixed vegetables (carrots, Brussels sprouts, potato)",
      "3 tbsp olive oil",
      "2 cloves garlic, minced",
      "1 tbsp mixed herbs (rosemary, thyme, oregano)",
      "1 lemon, sliced",
      "Salt and pepper to taste"
    ],
    nutritionInfo: {
      calories: 380,
      protein: 35,
      carbs: 20,
      fat: 18
    },
    sustainability: 3,
    dietaryTags: ["High-Protein", "One-Pan", "Gluten-Free"]
  }
];

// Define interface for the user context
interface UserContext {
  dietaryPreferences?: string;
  allergies?: string[];
  healthConditions?: string[];
  budgetLevel?: string;
  sustainabilityPreference?: string;
}

// Define interface for meal filters
interface MealFilters {
  mealType: string;
  diet: string;
  maxTime: number;
  maxCost: number;
  includeIngredients: string[];
  excludeIngredients: string[];
}

// Get personalized meal suggestions
export const getMealSuggestions = async (
  userContext: UserContext | null = null,
  filters: MealFilters
) => {
  try {
    // Simulate network delay
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // In production, this would call an API
    // For development, we'll filter the mock data based on user context and filters
    
    let filteredMeals = [...mockMeals];
    
    // Apply filters
    if (filters.mealType !== 'all') {
      // This is a simple mock - in production, we'd have a proper mealType field
      // Here we just filter randomly to simulate this
      filteredMeals = filteredMeals.filter(() => Math.random() > 0.5);
    }
    
    if (filters.diet !== 'all') {
      filteredMeals = filteredMeals.filter(meal => {
        if (filters.diet === 'vegetarian') {
          return meal.dietaryTags.includes('Vegetarian') || meal.dietaryTags.includes('Vegan');
        } else if (filters.diet === 'vegan') {
          return meal.dietaryTags.includes('Vegan');
        } else if (filters.diet === 'gluten-free') {
          return meal.dietaryTags.includes('Gluten-Free');
        }
        // More diet types would be handled here
        return true;
      });
    }
    
    // Filter by preparation time
    filteredMeals = filteredMeals.filter(meal => meal.prepTime <= filters.maxTime);
    
    // Filter by cost level
    filteredMeals = filteredMeals.filter(meal => meal.costLevel <= filters.maxCost);
    
    // Include ingredients (simple text match for mock)
    if (filters.includeIngredients.length > 0) {
      filteredMeals = filteredMeals.filter(meal => {
        const ingredientsText = meal.ingredients.join(' ').toLowerCase();
        return filters.includeIngredients.some(ingredient => 
          ingredientsText.includes(ingredient.toLowerCase())
        );
      });
    }
    
    // Exclude ingredients (simple text match for mock)
    if (filters.excludeIngredients.length > 0) {
      filteredMeals = filteredMeals.filter(meal => {
        const ingredientsText = meal.ingredients.join(' ').toLowerCase();
        return !filters.excludeIngredients.some(ingredient => 
          ingredientsText.includes(ingredient.toLowerCase())
        );
      });
    }
    
    // Apply user context if available
    if (userContext) {
      // Filter out meals that don't match dietary preferences
      if (userContext.dietaryPreferences) {
        const preference = userContext.dietaryPreferences.toLowerCase();
        filteredMeals = filteredMeals.filter(meal => {
          const tags = meal.dietaryTags.map(tag => tag.toLowerCase());
          
          if (preference === 'vegetarian') {
            return tags.includes('vegetarian') || tags.includes('vegan');
          } else if (preference === 'vegan') {
            return tags.includes('vegan');
          }
          
          // For other preferences, keep the meal by default
          // In a real app, we'd have more sophisticated matching
          return true;
        });
      }
      
      // Consider allergies (mock implementation)
      if (userContext.allergies && userContext.allergies.length > 0) {
        const allergies = userContext.allergies.map(a => a.toLowerCase());
        
        filteredMeals = filteredMeals.filter(meal => {
          const ingredientsText = meal.ingredients.join(' ').toLowerCase();
          
          // Simple check - in production this would be more sophisticated
          return !allergies.some(allergy => ingredientsText.includes(allergy));
        });
      }
    }
    
    return filteredMeals;
  } catch (error) {
    console.error('Error getting meal suggestions:', error);
    throw new Error('Failed to get meal suggestions');
  }
};