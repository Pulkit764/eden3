import axios from 'axios';

// Mock data for development - in production would use actual API calls
const mockAssistantResponses = [
  "Based on your profile, I'd recommend including more leafy greens in your diet. They're rich in nutrients and would help address your iron levels.",
  
  "For someone with your dietary preferences and budget, lentil soup would be an excellent choice. It's affordable, nutritious, and can be cooked in large batches.",
  
  "When you're looking for quick meal options that align with your health conditions, try vegetable stir-fry with brown rice and tofu. It takes about 15 minutes to prepare and provides balanced nutrition.",
  
  "Considering your sustainability preferences, locally grown seasonal vegetables would be your best option. They have a lower carbon footprint and are often more affordable when in season.",
  
  "To improve your iron intake while following a vegetarian diet, combine iron-rich foods like spinach and legumes with vitamin C sources like citrus fruits, which enhances iron absorption."
];

// Define interface for the user context
interface UserContext {
  dietaryPreferences?: string;
  allergies?: string[];
  healthConditions?: string[];
  budgetLevel?: string;
  sustainabilityPreference?: string;
}

// Define interface for chat message
interface ChatMessage {
  role: string;
  content: string;
  timestamp?: string;
}

// Simulate sending a message to the AI assistant
export const sendMessage = async (
  message: string, 
  userContext: UserContext | null = null,
  chatHistory: ChatMessage[] = []
) => {
  // In a real implementation, this would call the OpenAI API
  // For the mock, we'll implement basic logic to simulate responses
  
  try {
    // Simulate network delay
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    // In production, this would be an API call
    // const response = await axios.post('https://api.openai.com/v1/chat/completions', {
    //   model: 'gpt-4',
    //   messages: [
    //     { role: 'system', content: generateSystemPrompt(userContext) },
    //     ...formatChatHistory(chatHistory),
    //     { role: 'user', content: message }
    //   ],
    //   temperature: 0.7,
    //   max_tokens: 500
    // }, {
    //   headers: {
    //     'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`,
    //     'Content-Type': 'application/json'
    //   }
    // });
    
    // Get a random response for the mock
    const randomIndex = Math.floor(Math.random() * mockAssistantResponses.length);
    const randomResponse = mockAssistantResponses[randomIndex];
    
    // Enhance the response based on the message content
    let enhancedResponse = randomResponse;
    
    // Add personalization based on user context if available
    if (userContext) {
      if (userContext.dietaryPreferences) {
        enhancedResponse += ` This advice is specific to your ${userContext.dietaryPreferences} diet preference.`;
      }
      
      if (userContext.allergies && userContext.allergies.length > 0) {
        enhancedResponse += ` I've taken into account your food allergies when making these suggestions.`;
      }
    }
    
    // Check if message is a question about specific foods
    if (message.toLowerCase().includes('gluten') || message.toLowerCase().includes('celiac')) {
      enhancedResponse = "Gluten is found in wheat, barley, and rye. For someone with celiac disease, it's essential to avoid these grains and products made with them. Many alternatives like rice, quinoa, and certified gluten-free oats are safe options.";
    } else if (message.toLowerCase().includes('protein') && message.toLowerCase().includes('vegetarian')) {
      enhancedResponse = "Great vegetarian protein sources include: legumes (beans, lentils, chickpeas), tofu and tempeh, seitan, dairy products, eggs (if you eat them), quinoa, nuts and seeds. Combining different plant proteins throughout the day helps ensure you get all essential amino acids.";
    } else if (message.toLowerCase().includes('sustainable') || message.toLowerCase().includes('environment')) {
      enhancedResponse = "To make your diet more environmentally sustainable, focus on plant-forward eating, reduce food waste, choose local and seasonal foods when possible, and limit highly processed foods. Even small changes can have a meaningful impact over time.";
    }
    
    return { content: enhancedResponse };
  } catch (error) {
    console.error('Error in sendMessage:', error);
    throw new Error('Failed to get response from assistant');
  }
};

// Helper function to generate system prompt with user context
const generateSystemPrompt = (userContext: UserContext | null) => {
  let prompt = `You are EDEN, an AI Nutrition Coach. You provide personalized, evidence-based advice on nutrition, diet, and food choices. Your information comes from reputable nutritional science sources.

Your responses should be:
- Culturally sensitive and inclusive
- Based on current nutritional science
- Practical and actionable
- Mindful of sustainability and environmental impact
- Considerate of budget and accessibility concerns

You should NOT:
- Give specific medical advice or treatment recommendations
- Make claims that aren't supported by scientific consensus
- Promote extreme or potentially harmful eating patterns`;

  // Add user-specific context if available
  if (userContext) {
    prompt += `\n\nUser Context:`;
    
    if (userContext.dietaryPreferences) {
      prompt += `\n- Dietary Preferences: ${userContext.dietaryPreferences}`;
    }
    
    if (userContext.allergies && userContext.allergies.length > 0) {
      prompt += `\n- Allergies: ${userContext.allergies.join(', ')}`;
    }
    
    if (userContext.healthConditions && userContext.healthConditions.length > 0) {
      prompt += `\n- Health Considerations: ${userContext.healthConditions.join(', ')}`;
    }
    
    if (userContext.budgetLevel) {
      prompt += `\n- Budget Level: ${userContext.budgetLevel}`;
    }
    
    if (userContext.sustainabilityPreference) {
      prompt += `\n- Sustainability Importance: ${userContext.sustainabilityPreference}`;
    }
  }

  return prompt;
};

// Helper function to format chat history for API call
const formatChatHistory = (chatHistory: ChatMessage[]) => {
  return chatHistory.map(msg => ({
    role: msg.role,
    content: msg.content
  }));
};