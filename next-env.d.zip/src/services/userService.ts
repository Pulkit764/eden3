// User profile service

// Mock user profile storage (would use a real database in production)
let mockUserProfiles: any[] = [];

// Update or create user profile
export const updateUserProfile = async (profileData: any): Promise<any> => {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  // Check if profile exists
  const existingProfileIndex = mockUserProfiles.findIndex(
    profile => profile.id === profileData.id || profile.email === profileData.email
  );
  
  if (existingProfileIndex >= 0) {
    // Update existing profile
    mockUserProfiles[existingProfileIndex] = {
      ...mockUserProfiles[existingProfileIndex],
      ...profileData,
      updatedAt: new Date().toISOString()
    };
    
    return mockUserProfiles[existingProfileIndex];
  } else {
    // Create new profile
    const newProfile = {
      id: profileData.id || `profile-${Date.now()}`,
      ...profileData,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    
    mockUserProfiles.push(newProfile);
    return newProfile;
  }
};

// Get user profile by ID or email
export const getUserProfile = async (identifier: string): Promise<any> => {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 500));
  
  // Find profile by ID or email
  const profile = mockUserProfiles.find(
    p => p.id === identifier || p.email === identifier
  );
  
  if (!profile) {
    throw new Error('Profile not found');
  }
  
  return profile;
};

// Delete user profile
export const deleteUserProfile = async (identifier: string): Promise<void> => {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 800));
  
  // Find and remove profile
  const profileIndex = mockUserProfiles.findIndex(
    p => p.id === identifier || p.email === identifier
  );
  
  if (profileIndex === -1) {
    throw new Error('Profile not found');
  }
  
  mockUserProfiles.splice(profileIndex, 1);
};

// Update specific user preference
export const updateUserPreference = async (userId: string, key: string, value: any): Promise<any> => {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 600));
  
  // Find profile
  const profileIndex = mockUserProfiles.findIndex(p => p.id === userId);
  
  if (profileIndex === -1) {
    throw new Error('Profile not found');
  }
  
  // Update specific preference
  mockUserProfiles[profileIndex] = {
    ...mockUserProfiles[profileIndex],
    [key]: value,
    updatedAt: new Date().toISOString()
  };
  
  return mockUserProfiles[profileIndex];
};