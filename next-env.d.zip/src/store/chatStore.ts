import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface ChatMessage {
  role: string;
  content: string;
  timestamp: string;
  isError?: boolean;
}

interface ChatState {
  messages: ChatMessage[];
  addMessage: (message: ChatMessage) => void;
  clearMessages: () => void;
}

const useChatStore = create<ChatState>()(
  persist(
    (set) => ({
      messages: [],
      addMessage: (message) => set((state) => ({ messages: [...state.messages, message] })),
      clearMessages: () => set({ messages: [] }),
    }),
    {
      name: 'eden-chat-storage',
    }
  )
);

export default useChatStore;