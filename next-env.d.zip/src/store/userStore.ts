import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface UserProfile {
  id?: string;
  name: string;
  email: string;
  dietaryPreferences?: string;
  householdSize?: number;
  budgetLevel?: string;
  allergies?: string[];
  healthConditions?: string[];
  cookingSkill?: string;
  sustainabilityPreference?: string;
  createdAt?: string;
  updatedAt?: string;
}

interface UserState {
  userProfile: UserProfile | null;
  setUserProfile: (profile: UserProfile) => void;
  updateUserPreference: (key: string, value: any) => void;
  clearUserProfile: () => void;
}

const useUserStore = create<UserState>()(
  persist(
    (set) => ({
      userProfile: null,
      setUserProfile: (profile) => set({ userProfile: profile }),
      updateUserPreference: (key, value) => 
        set((state) => ({
          userProfile: state.userProfile ? {
            ...state.userProfile,
            [key]: value,
            updatedAt: new Date().toISOString()
          } : null
        })),
      clearUserProfile: () => set({ userProfile: null }),
    }),
    {
      name: 'eden-user-storage',
    }
  )
);

export default useUserStore;