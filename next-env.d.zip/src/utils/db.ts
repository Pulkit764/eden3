import Dexie from 'dexie';

// Define the database
export class EdenDatabase extends Dexie {
  userProfile: Dexie.Table<any, string>;
  meals: Dexie.Table<any, string>;
  chatHistory: Dexie.Table<any, number>;
  factChecks: Dexie.Table<any, string>;

  constructor() {
    super('EdenDatabase');
    
    this.version(1).stores({
      userProfile: 'id',
      meals: 'id, name, diet, *tags',
      chatHistory: '++id, timestamp',
      factChecks: 'id, url, verdict, timestamp'
    });
    
    this.userProfile = this.table('userProfile');
    this.meals = this.table('meals');
    this.chatHistory = this.table('chatHistory');
    this.factChecks = this.table('factChecks');
  }
}

let db: EdenDatabase;

export const initializeDB = () => {
  db = new EdenDatabase();
  return db;
};

export const getDB = () => {
  if (!db) {
    return initializeDB();
  }
  return db;
};

// Basic CRUD operations

export const saveData = async (table: string, data: any) => {
  const db = getDB();
  return await db.table(table).put(data);
};

export const getData = async (table: string, id: any) => {
  const db = getDB();
  return await db.table(table).get(id);
};

export const getAllData = async (table: string) => {
  const db = getDB();
  return await db.table(table).toArray();
};

export const deleteData = async (table: string, id: any) => {
  const db = getDB();
  return await db.table(table).delete(id);
};

// Custom functions for offline support

export const storeMessages = async (messages: any[]) => {
  const db = getDB();
  const batch = messages.map(message => ({
    ...message,
    timestamp: message.timestamp || new Date().toISOString()
  }));
  return await db.chatHistory.bulkAdd(batch);
};

export const saveMealResult = async (meal: any) => {
  const db = getDB();
  return await db.meals.put({
    ...meal,
    savedAt: new Date().toISOString()
  });
};

export const getMealsByDiet = async (diet: string) => {
  const db = getDB();
  return await db.meals.where('diet').equals(diet).toArray();
};

export const searchMealsByTags = async (tags: string[]) => {
  const db = getDB();
  return await db.meals
    .where('tags')
    .anyOf(tags)
    .toArray();
};

export const saveFactCheck = async (data: any) => {
  const db = getDB();
  return await db.factChecks.put({
    ...data,
    timestamp: new Date().toISOString()
  });
};