import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import LanguageDetector from 'i18next-browser-languagedetector';

// Load translations
import enTranslation from '../locales/en.json';
import esTranslation from '../locales/es.json';
import frTranslation from '../locales/fr.json';
import zhTranslation from '../locales/zh.json';
import hiTranslation from '../locales/hi.json';
import arTranslation from '../locales/ar.json';
import swTranslation from '../locales/sw.json';

const resources = {
  en: { translation: enTranslation },
  es: { translation: esTranslation },
  fr: { translation: frTranslation },
  zh: { translation: zhTranslation },
  hi: { translation: hiTranslation },
  ar: { translation: arTranslation },
  sw: { translation: swTranslation },
};

i18n
  .use(initReactI18next)
  .use(LanguageDetector)
  .init({
    resources,
    fallbackLng: 'en',
    interpolation: {
      escapeValue: false, // React already escapes values
    },
    detection: {
      order: ['navigator', 'htmlTag', 'path', 'localStorage'],
      caches: ['localStorage'],
    },
  });

export default i18n;